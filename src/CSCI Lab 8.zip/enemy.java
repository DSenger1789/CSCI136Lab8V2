//Wit Sampson
// Data Created: 10/19/2018
// The purpose of this class is to put the enemy of the player into the game and if the player hits the enemy, they lose
public class enemy {
	
	String enemyName;
	String imagePath;
	
	public enemy(String imagePath) {
		this.enemyName = "enemy";
		this.imagePath = imagePath;
	}
	
	public void Movement() {
		Movement move = new Movement(enemyName);
	}
	
}