//Wit Sampson
// Data Created: 10/19/2018
//The purpose of this class is to give movement to the game
public class Movement {
	String objectMoving;
	
	public Movement(String objectMoving) {
		this.objectMoving = objectMoving;
	}
	
	public void movement() {
		
	}
	
	
}